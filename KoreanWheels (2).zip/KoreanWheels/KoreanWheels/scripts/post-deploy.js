#!/usr/bin/env node

/**
 * Post-deploy script для автоматического выполнения миграций
 * Запускается после успешного деплоя на Vercel
 */

import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

async function runMigrations() {
  console.log('🚀 Запуск миграций базы данных...');
  
  if (!process.env.DATABASE_URL) {
    console.error('❌ DATABASE_URL не найден в переменных окружения');
    process.exit(1);
  }

  try {
    const { stdout, stderr } = await execAsync('npm run db:push');
    
    if (stderr) {
      console.error('⚠️  Предупреждения:', stderr);
    }
    
    console.log('✅ Миграции выполнены успешно');
    console.log(stdout);
  } catch (error) {
    console.error('❌ Ошибка при выполнении миграций:', error.message);
    process.exit(1);
  }
}

// Запускаем только в продакшн среде
if (process.env.NODE_ENV === 'production') {
  runMigrations();
} else {
  console.log('⏭️  Миграции пропущены (не продакшн среда)');
} 