import { Star, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import type { Car } from '@shared/schema';

interface CarCardProps {
  car: Car;
  onShowDetails: (car: Car) => void;
}

export function CarCard({ car, onShowDetails }: CarCardProps) {
  const { addToCart } = useCart();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return <Badge className="bg-primary/10 text-primary">Новый</Badge>;
      case 'available':
        return <Badge className="bg-green-100 text-green-800">В наличии</Badge>;
      case 'premium':
        return <Badge className="bg-purple-100 text-purple-800">Премиум</Badge>;
      case 'hit':
        return <Badge className="bg-orange-100 text-orange-800">Хит</Badge>;
      case 'electric':
        return <Badge className="bg-green-100 text-green-800">Электро</Badge>;
      case 'sport':
        return <Badge className="bg-blue-100 text-blue-800">Спорт</Badge>;
      default:
        return null;
    }
  };

  return (
    <Card className="overflow-hidden car-card shadow-sm" data-testid={`card-car-${car.id}`}>
      <img 
        src={car.image} 
        alt={car.name} 
        className="w-full h-48 object-cover"
        data-testid={`img-car-${car.id}`}
      />
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-foreground" data-testid={`text-car-name-${car.id}`}>
            {car.name}
          </h3>
          {getStatusBadge(car.status)}
        </div>
        <p className="text-muted-foreground text-sm mb-3" data-testid={`text-car-specs-${car.id}`}>
          {car.year} • {car.bodyType === 'sedan' ? 'Седан' : car.bodyType === 'suv' ? 'SUV' : car.bodyType} • {car.engine}
        </p>
        <div className="flex justify-between items-center mb-4">
          <span className="text-2xl font-bold text-foreground" data-testid={`text-car-price-${car.id}`}>
            {parseInt(car.price).toLocaleString('ru-RU')}₽
          </span>
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="text-sm text-muted-foreground" data-testid={`text-car-rating-${car.id}`}>
              {car.rating}
            </span>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={() => addToCart(car.id)}
            className="flex-1"
            data-testid={`button-add-cart-${car.id}`}
          >
            В корзину
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onShowDetails(car)}
            data-testid={`button-details-${car.id}`}
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
