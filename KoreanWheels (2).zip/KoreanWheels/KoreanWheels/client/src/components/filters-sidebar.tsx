import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';

interface Filters {
  brands: string[];
  minPrice: number;
  maxPrice: number;
  year?: number;
  bodyTypes: string[];
}

interface FiltersSidebarProps {
  filters: Filters;
  onFiltersChange: (filters: Filters) => void;
  onApplyFilters: () => void;
}

export function FiltersSidebar({ filters, onFiltersChange, onApplyFilters }: FiltersSidebarProps) {
  const [priceRange, setPriceRange] = useState([filters.minPrice, filters.maxPrice]);

  const handleBrandChange = (brand: string, checked: boolean) => {
    const newBrands = checked
      ? [...filters.brands, brand]
      : filters.brands.filter(b => b !== brand);
    
    onFiltersChange({ ...filters, brands: newBrands });
  };

  const handleBodyTypeChange = (bodyType: string) => {
    const isSelected = filters.bodyTypes.includes(bodyType);
    const newBodyTypes = isSelected
      ? filters.bodyTypes.filter(bt => bt !== bodyType)
      : [...filters.bodyTypes, bodyType];
    
    onFiltersChange({ ...filters, bodyTypes: newBodyTypes });
  };

  const handlePriceChange = (values: number[]) => {
    setPriceRange(values);
    onFiltersChange({
      ...filters,
      minPrice: values[0],
      maxPrice: values[1],
    });
  };

  const handleYearChange = (year: string) => {
    onFiltersChange({
      ...filters,
      year: year === 'all' ? undefined : parseInt(year),
    });
  };

  return (
    <aside className="lg:w-80 filter-sidebar">
      <Card className="p-6 space-y-6">
        <h3 className="text-lg font-semibold text-foreground" data-testid="text-filters-title">
          Фильтры
        </h3>
        
        {/* Brand Filter */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground">Марка</h4>
          <div className="space-y-2">
            {[
              { brand: 'Hyundai', count: 2 },
              { brand: 'Kia', count: 2 },
              { brand: 'Genesis', count: 2 },
            ].map(({ brand, count }) => (
              <div key={brand} className="flex items-center space-x-2">
                <Checkbox
                  id={`brand-${brand.toLowerCase()}`}
                  checked={filters.brands.includes(brand)}
                  onCheckedChange={(checked) => handleBrandChange(brand, checked as boolean)}
                  data-testid={`checkbox-brand-${brand.toLowerCase()}`}
                />
                <label 
                  htmlFor={`brand-${brand.toLowerCase()}`}
                  className="text-foreground cursor-pointer flex-1 flex justify-between"
                >
                  <span>{brand}</span>
                  <span className="text-muted-foreground text-sm">({count})</span>
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Price Range */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground">Цена</h4>
          <div className="space-y-2">
            <Slider
              value={priceRange}
              onValueChange={handlePriceChange}
              max={5000000}
              min={500000}
              step={50000}
              className="w-full"
              data-testid="slider-price"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span data-testid="text-min-price">{priceRange[0].toLocaleString('ru-RU')}₽</span>
              <span data-testid="text-max-price">{priceRange[1].toLocaleString('ru-RU')}₽</span>
            </div>
          </div>
        </div>

        {/* Year Filter */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground">Год выпуска</h4>
          <Select value={filters.year?.toString() || 'all'} onValueChange={handleYearChange}>
            <SelectTrigger data-testid="select-year">
              <SelectValue placeholder="Все годы" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все годы</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
              <SelectItem value="2021">2021</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Body Type */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground">Тип кузова</h4>
          <div className="grid grid-cols-2 gap-2">
            {[
              { type: 'sedan', label: 'Седан' },
              { type: 'suv', label: 'SUV' },
              { type: 'hatchback', label: 'Хэтчбек' },
              { type: 'coupe', label: 'Купе' },
            ].map(({ type, label }) => (
              <Button
                key={type}
                variant={filters.bodyTypes.includes(type) ? 'default' : 'outline'}
                size="sm"
                onClick={() => handleBodyTypeChange(type)}
                className="text-sm"
                data-testid={`button-body-type-${type}`}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        <Button
          onClick={onApplyFilters}
          className="w-full"
          data-testid="button-apply-filters"
        >
          Применить фильтры
        </Button>
      </Card>
    </aside>
  );
}
