import { useState } from 'react';
import { Car, Search, ShoppingCart, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/hooks/use-cart';

interface NavigationProps {
  onSearch: (query: string) => void;
  searchQuery: string;
}

export function Navigation({ onSearch, searchQuery }: NavigationProps) {
  const { setIsOpen, cartCount } = useCart();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="text-2xl font-bold text-primary">
              <Car className="inline mr-2" />
              Korean Auto Hub
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="text-foreground hover:text-primary transition-colors" data-testid="nav-catalog">
                Каталог
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-about">
                О нас
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-contacts">
                Контакты
              </a>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Search Bar */}
            <div className="hidden sm:flex relative">
              <Input
                type="text"
                placeholder="Поиск по модели..."
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                className="pl-10 pr-4 py-2 w-64"
                data-testid="input-search"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </div>
            
            {/* Cart Button */}
            <Button
              onClick={() => setIsOpen(true)}
              className="relative"
              data-testid="button-cart"
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Корзина</span>
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-destructive text-white text-xs rounded-full w-5 h-5 flex items-center justify-center" data-testid="text-cart-count">
                  {cartCount}
                </span>
              )}
            </Button>
            
            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t border-border">
            <div className="mb-4">
              <Input
                type="text"
                placeholder="Поиск по модели..."
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                className="w-full"
                data-testid="input-mobile-search"
              />
            </div>
            <nav className="flex flex-col space-y-2">
              <a href="#" className="text-foreground hover:text-primary transition-colors py-2" data-testid="nav-mobile-catalog">
                Каталог
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors py-2" data-testid="nav-mobile-about">
                О нас
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors py-2" data-testid="nav-mobile-contacts">
                Контакты
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
