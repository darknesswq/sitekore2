import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/use-cart';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { orderRequestSchema as baseOrderRequestSchema } from '@shared/schema';
import { z } from 'zod';

const orderRequestSchema = baseOrderRequestSchema.extend({
  terms: z.boolean().refine(val => val === true, {
    message: "Необходимо согласиться с условиями"
  })
});

type OrderRequestFormData = z.infer<typeof orderRequestSchema>;

interface CheckoutFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CheckoutForm({ isOpen, onClose }: CheckoutFormProps) {
  const { cartItems, clearCart } = useCart();
  const { toast } = useToast();

  const form = useForm<OrderRequestFormData>({
    resolver: zodResolver(orderRequestSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      city: '',
      address: '',
      comments: '',
      terms: false,
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: Omit<OrderRequestFormData, 'terms'>) => {
      const res = await apiRequest('POST', '/api/orders', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Заявка успешно отправлена!",
        description: "Мы свяжемся с вами в ближайшее время для обсуждения деталей.",
      });
      clearCart();
      onClose();
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить заявку. Попробуйте еще раз.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: OrderRequestFormData) => {
    const { terms, ...orderData } = data;
    createOrderMutation.mutate(orderData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="modal-checkout">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-2xl font-bold" data-testid="text-checkout-title">
              Заявка на заказ
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-checkout"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Personal Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Контактная информация</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Имя *</Label>
                <Input
                  id="firstName"
                  {...form.register('firstName')}
                  placeholder="Ваше имя"
                  data-testid="input-first-name"
                />
                {form.formState.errors.firstName && (
                  <p className="text-destructive text-sm mt-1">
                    {form.formState.errors.firstName.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="lastName">Фамилия *</Label>
                <Input
                  id="lastName"
                  {...form.register('lastName')}
                  placeholder="Ваша фамилия"
                  data-testid="input-last-name"
                />
                {form.formState.errors.lastName && (
                  <p className="text-destructive text-sm mt-1">
                    {form.formState.errors.lastName.message}
                  </p>
                )}
              </div>
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                {...form.register('email')}
                placeholder="your@email.com"
                data-testid="input-email"
              />
              {form.formState.errors.email && (
                <p className="text-destructive text-sm mt-1">
                  {form.formState.errors.email.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="phone">Телефон *</Label>
              <Input
                id="phone"
                type="tel"
                {...form.register('phone')}
                placeholder="+7 (999) 123-45-67"
                data-testid="input-phone"
              />
              {form.formState.errors.phone && (
                <p className="text-destructive text-sm mt-1">
                  {form.formState.errors.phone.message}
                </p>
              )}
            </div>
          </div>
          
          {/* Delivery Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Информация о местонахождении</h3>
            <div>
              <Label htmlFor="city">Город *</Label>
              <Input
                id="city"
                {...form.register('city')}
                placeholder="Москва"
                data-testid="input-city"
              />
              {form.formState.errors.city && (
                <p className="text-destructive text-sm mt-1">
                  {form.formState.errors.city.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="address">Адрес *</Label>
              <Textarea
                id="address"
                {...form.register('address')}
                placeholder="Улица, дом, квартира"
                className="min-h-[80px]"
                data-testid="textarea-address"
              />
              {form.formState.errors.address && (
                <p className="text-destructive text-sm mt-1">
                  {form.formState.errors.address.message}
                </p>
              )}
            </div>
          </div>

          {/* Comments */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Дополнительная информация</h3>
            <div>
              <Label htmlFor="comments">Комментарии к заказу</Label>
              <Textarea
                id="comments"
                {...form.register('comments')}
                placeholder="Укажите ваши пожелания, вопросы или дополнительную информацию..."
                className="min-h-[100px]"
                data-testid="textarea-comments"
              />
              {form.formState.errors.comments && (
                <p className="text-destructive text-sm mt-1">
                  {form.formState.errors.comments.message}
                </p>
              )}
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Выбранные автомобили</h3>
            <Card>
              <CardContent className="p-4 space-y-3">
                {cartItems.map((item, index) => (
                  <div key={item.id} className="flex justify-between items-center">
                    <div>
                      <span className="font-medium">{item.car.name}</span>
                      <span className="text-muted-foreground text-sm ml-2">
                        ({item.car.year}, {item.car.bodyType === 'sedan' ? 'Седан' : item.car.bodyType === 'suv' ? 'SUV' : item.car.bodyType})
                      </span>
                    </div>
                    <span className="font-medium text-foreground" data-testid={`text-checkout-car-price-${index}`}>
                      {parseInt(item.car.price).toLocaleString('ru-RU')}₽
                    </span>
                  </div>
                ))}
                <div className="border-t border-border pt-2">
                  <div className="flex justify-between">
                    <span className="text-lg font-semibold text-foreground">Всего автомобилей:</span>
                    <span className="text-lg font-semibold text-foreground" data-testid="text-checkout-count">
                      {cartItems.length} шт.
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Terms */}
          <div className="flex items-start space-x-3">
            <Checkbox
              id="terms"
              checked={form.watch('terms')}
              onCheckedChange={(checked) => form.setValue('terms', checked as boolean)}
              data-testid="checkbox-terms"
            />
            <Label htmlFor="terms" className="text-sm text-muted-foreground">
              Я согласен с{' '}
              <a href="#" className="text-primary hover:underline">
                условиями обслуживания
              </a>{' '}
              и{' '}
              <a href="#" className="text-primary hover:underline">
                политикой конфиденциальности
              </a>
            </Label>
          </div>
          {form.formState.errors.terms && (
            <p className="text-destructive text-sm">
              {form.formState.errors.terms.message}
            </p>
          )}
          
          <div className="flex space-x-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              data-testid="button-cancel-checkout"
            >
              Отменить
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={createOrderMutation.isPending}
              data-testid="button-submit-order"
            >
              {createOrderMutation.isPending ? 'Отправка...' : 'Отправить заявку'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}