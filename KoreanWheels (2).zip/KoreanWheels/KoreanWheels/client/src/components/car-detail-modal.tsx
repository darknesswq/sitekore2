import { useState } from 'react';
import { X, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import type { Car } from '@shared/schema';

interface CarDetailModalProps {
  car: Car | null;
  isOpen: boolean;
  onClose: () => void;
}

export function CarDetailModal({ car, isOpen, onClose }: CarDetailModalProps) {
  const { addToCart } = useCart();
  const [selectedImage, setSelectedImage] = useState(0);

  if (!car) return null;

  const allImages = [car.image, ...car.images];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-car-details">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <DialogTitle className="text-2xl font-bold" data-testid="text-modal-car-name">
              {car.name}
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-modal"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <img 
              src={allImages[selectedImage]} 
              alt={car.name} 
              className="w-full rounded-lg mb-4"
              data-testid="img-modal-car-main"
            />
            
            {/* Image Gallery */}
            <div className="flex space-x-2">
              {allImages.map((image, index) => (
                <img 
                  key={index}
                  src={image} 
                  alt={`${car.name} view ${index + 1}`} 
                  className={`w-20 h-16 object-cover rounded border-2 cursor-pointer ${
                    selectedImage === index ? 'border-primary' : 'border-border hover:border-primary'
                  }`}
                  onClick={() => setSelectedImage(index)}
                  data-testid={`img-gallery-${index}`}
                />
              ))}
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <div className="text-3xl font-bold text-foreground mb-2" data-testid="text-modal-car-price">
                {parseInt(car.price).toLocaleString('ru-RU')}₽
              </div>
              <p className="text-muted-foreground" data-testid="text-modal-car-description">
                {car.description}
              </p>
            </div>
            
            {/* Specifications */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">Технические характеристики</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Год выпуска:</span>
                  <span className="font-medium" data-testid="text-spec-year">{car.year}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Двигатель:</span>
                  <span className="font-medium" data-testid="text-spec-engine">{car.engine}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Мощность:</span>
                  <span className="font-medium" data-testid="text-spec-power">{car.power}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Привод:</span>
                  <span className="font-medium" data-testid="text-spec-drivetrain">{car.drivetrain}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Коробка:</span>
                  <span className="font-medium" data-testid="text-spec-transmission">{car.transmission}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Расход:</span>
                  <span className="font-medium" data-testid="text-spec-consumption">{car.fuelConsumption}</span>
                </div>
              </div>
            </div>
            
            {/* Features */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-foreground">Комплектация</h3>
              <div className="flex flex-wrap gap-2">
                {car.features.map((feature, index) => (
                  <Badge key={index} variant="secondary" data-testid={`badge-feature-${index}`}>
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                onClick={() => addToCart(car.id)}
                className="flex-1"
                data-testid="button-modal-add-cart"
              >
                Добавить в корзину
              </Button>
              <Button
                variant="outline"
                size="icon"
                data-testid="button-add-wishlist"
              >
                <Heart className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
