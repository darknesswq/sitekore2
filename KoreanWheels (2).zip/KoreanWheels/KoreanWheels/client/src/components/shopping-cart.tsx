import { X, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useCart } from '@/hooks/use-cart';

interface ShoppingCartProps {
  onCheckout: () => void;
}

export function ShoppingCart({ onCheckout }: ShoppingCartProps) {
  const { isOpen, setIsOpen, cartItems, removeFromCart, cartTotal, cartCount, isLoading } = useCart();

  const handleCheckout = () => {
    setIsOpen(false);
    onCheckout();
  };

  if (isLoading) {
    return (
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent className="w-96">
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent className="w-96 flex flex-col" data-testid="sheet-cart">
        <SheetHeader>
          <div className="flex justify-between items-center">
            <SheetTitle data-testid="text-cart-title">Корзина</SheetTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              data-testid="button-close-cart"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </SheetHeader>
        
        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto space-y-4 mt-6">
          {cartItems.length === 0 ? (
            <div className="text-center text-muted-foreground py-8" data-testid="text-empty-cart">
              Корзина пуста
            </div>
          ) : (
            cartItems.map((item) => (
              <div 
                key={item.id} 
                className="flex items-center space-x-3 p-3 border border-border rounded-lg"
                data-testid={`cart-item-${item.car.id}`}
              >
                <img 
                  src={item.car.image} 
                  alt={item.car.name} 
                  className="w-16 h-12 object-cover rounded"
                  data-testid={`img-cart-item-${item.car.id}`}
                />
                <div className="flex-1">
                  <h4 className="font-medium text-foreground" data-testid={`text-cart-item-name-${item.car.id}`}>
                    {item.car.name}
                  </h4>
                  <p className="text-sm text-muted-foreground" data-testid={`text-cart-item-specs-${item.car.id}`}>
                    {item.car.year} • {item.car.bodyType === 'sedan' ? 'Седан' : item.car.bodyType === 'suv' ? 'SUV' : item.car.bodyType}
                  </p>
                  <p className="font-semibold text-foreground" data-testid={`text-cart-item-price-${item.car.id}`}>
                    {parseInt(item.car.price).toLocaleString('ru-RU')}₽
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeFromCart(item.car.id)}
                  className="text-destructive hover:text-destructive/80"
                  data-testid={`button-remove-cart-${item.car.id}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
        
        {/* Cart Summary */}
        {cartItems.length > 0 && (
          <div className="border-t border-border pt-4 mt-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-muted-foreground">Количество:</span>
              <span className="font-medium" data-testid="text-cart-count">
                {cartCount} {cartCount === 1 ? 'автомобиль' : cartCount < 5 ? 'автомобиля' : 'автомобилей'}
              </span>
            </div>
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-semibold text-foreground">Итого:</span>
              <span className="text-2xl font-bold text-foreground" data-testid="text-cart-total">
                {cartTotal.toLocaleString('ru-RU')}₽
              </span>
            </div>
            <Button
              onClick={handleCheckout}
              className="w-full"
              data-testid="button-checkout"
            >
              Оформить заказ
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
