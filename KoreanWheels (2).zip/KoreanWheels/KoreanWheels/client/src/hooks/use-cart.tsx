import { createContext, useContext, useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { Car, CartItem } from '@shared/schema';

interface CartContextType {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  cartItems: (CartItem & { car: Car })[];
  addToCart: (carId: string) => void;
  removeFromCart: (carId: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  isLoading: boolean;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cartItems = [], isLoading } = useQuery<(CartItem & { car: Car })[]>({
    queryKey: ['/api/cart'],
  });

  const addToCartMutation = useMutation({
    mutationFn: async (carId: string) => {
      const res = await apiRequest('POST', '/api/cart', { carId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Добавлено в корзину",
        description: "Автомобиль успешно добавлен в корзину",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить автомобиль в корзину",
        variant: "destructive",
      });
    },
  });

  const removeFromCartMutation = useMutation({
    mutationFn: async (carId: string) => {
      await apiRequest('DELETE', `/api/cart/${carId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Удалено из корзины",
        description: "Автомобиль удален из корзины",
      });
    },
  });

  const clearCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', '/api/cart');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
  });

  const cartTotal = cartItems.reduce((sum, item) => sum + parseFloat(item.car.price), 0);
  const cartCount = cartItems.length;

  const addToCart = (carId: string) => {
    addToCartMutation.mutate(carId);
  };

  const removeFromCart = (carId: string) => {
    removeFromCartMutation.mutate(carId);
  };

  const clearCart = () => {
    clearCartMutation.mutate();
  };

  return (
    <CartContext.Provider
      value={{
        isOpen,
        setIsOpen,
        cartItems,
        addToCart,
        removeFromCart,
        clearCart,
        cartTotal,
        cartCount,
        isLoading,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
