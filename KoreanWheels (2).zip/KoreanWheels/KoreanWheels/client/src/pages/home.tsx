import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Grid, List } from 'lucide-react';
import { Navigation } from '@/components/navigation';
import { CarCard } from '@/components/car-card';
import { CarDetailModal } from '@/components/car-detail-modal';
import { ShoppingCart } from '@/components/shopping-cart';
import { CheckoutForm } from '@/components/checkout-form';
import { FiltersSidebar } from '@/components/filters-sidebar';
import type { Car } from '@shared/schema';

interface Filters {
  brands: string[];
  minPrice: number;
  maxPrice: number;
  year?: number;
  bodyTypes: string[];
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCar, setSelectedCar] = useState<Car | null>(null);
  const [isCarDetailOpen, setIsCarDetailOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [sortBy, setSortBy] = useState('popular');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filters, setFilters] = useState<Filters>({
    brands: [],
    minPrice: 500000,
    maxPrice: 5000000,
    bodyTypes: [],
  });
  const [appliedFilters, setAppliedFilters] = useState<Filters>(filters);

  // Build query parameters
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    
    if (searchQuery.trim()) {
      params.append('search', searchQuery.trim());
    }
    
    if (appliedFilters.brands.length > 0) {
      appliedFilters.brands.forEach(brand => params.append('brands', brand));
    }
    
    if (appliedFilters.minPrice > 500000) {
      params.append('minPrice', appliedFilters.minPrice.toString());
    }
    
    if (appliedFilters.maxPrice < 5000000) {
      params.append('maxPrice', appliedFilters.maxPrice.toString());
    }
    
    if (appliedFilters.year) {
      params.append('year', appliedFilters.year.toString());
    }
    
    if (appliedFilters.bodyTypes.length > 0) {
      appliedFilters.bodyTypes.forEach(type => params.append('bodyTypes', type));
    }
    
    return params.toString();
  };

  const { data: cars = [], isLoading } = useQuery<Car[]>({
    queryKey: ['/api/cars', buildQueryParams()],
    queryFn: async () => {
      const queryParams = buildQueryParams();
      const url = queryParams ? `/api/cars?${queryParams}` : '/api/cars';
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch cars');
      }
      return response.json();
    },
  });

  // Sort cars
  const sortedCars = [...cars].sort((a, b) => {
    switch (sortBy) {
      case 'price-asc':
        return parseFloat(a.price) - parseFloat(b.price);
      case 'price-desc':
        return parseFloat(b.price) - parseFloat(a.price);
      case 'year-new':
        return b.year - a.year;
      case 'popular':
      default:
        return parseFloat(b.rating) - parseFloat(a.rating);
    }
  });

  const handleShowCarDetails = (car: Car) => {
    setSelectedCar(car);
    setIsCarDetailOpen(true);
  };

  const handleApplyFilters = () => {
    setAppliedFilters({ ...filters });
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation onSearch={setSearchQuery} searchQuery={searchQuery} />

      {/* Hero Section */}
      <section className="hero-gradient text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4" data-testid="text-hero-title">
            Премиальные корейские автомобили
          </h1>
          <p className="text-xl mb-8 text-white/90" data-testid="text-hero-subtitle">
            Hyundai, Kia, Genesis - качество и инновации из Кореи
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Button
              onClick={scrollToTop}
              className="bg-white text-primary hover:bg-white/90"
              data-testid="button-catalog"
            >
              Смотреть каталог
            </Button>
            <Button
              variant="outline"
              className="border-white text-white hover:bg-white/10"
              data-testid="button-consultation"
            >
              Консультация
            </Button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <FiltersSidebar
            filters={filters}
            onFiltersChange={setFilters}
            onApplyFilters={handleApplyFilters}
          />

          {/* Car Catalog */}
          <div className="flex-1">
            {/* Results Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div>
                <h2 className="text-2xl font-bold text-foreground" data-testid="text-catalog-title">
                  Каталог автомобилей
                </h2>
                <p className="text-muted-foreground" data-testid="text-results-count">
                  Найдено {sortedCars.length} автомобилей
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48" data-testid="select-sort">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">По популярности</SelectItem>
                    <SelectItem value="price-asc">По цене: возрастание</SelectItem>
                    <SelectItem value="price-desc">По цене: убывание</SelectItem>
                    <SelectItem value="year-new">По году: новые</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex border border-border rounded-lg">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'ghost'}
                    size="icon"
                    onClick={() => setViewMode('grid')}
                    className="rounded-r-none"
                    data-testid="button-view-grid"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'ghost'}
                    size="icon"
                    onClick={() => setViewMode('list')}
                    className="rounded-l-none"
                    data-testid="button-view-list"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            )}

            {/* Empty State */}
            {!isLoading && sortedCars.length === 0 && (
              <div className="text-center py-12" data-testid="text-no-results">
                <p className="text-muted-foreground">Автомобили не найдены</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Попробуйте изменить критерии поиска или фильтры
                </p>
              </div>
            )}

            {/* Car Grid */}
            {!isLoading && sortedCars.length > 0 && (
              <div className={`grid gap-6 ${
                viewMode === 'grid' 
                  ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' 
                  : 'grid-cols-1'
              }`} data-testid="container-cars">
                {sortedCars.map((car) => (
                  <CarCard
                    key={car.id}
                    car={car}
                    onShowDetails={handleShowCarDetails}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="text-xl font-bold text-primary mb-4">
                Korean Auto Hub
              </div>
              <p className="text-muted-foreground text-sm">
                Официальный дилер корейских автомобилей. Качество, надежность и инновации из Кореи.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Каталог</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Hyundai</a></li>
                <li><a href="#" className="hover:text-primary">Kia</a></li>
                <li><a href="#" className="hover:text-primary">Genesis</a></li>
                <li><a href="#" className="hover:text-primary">Новые поступления</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Услуги</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Тест-драйв</a></li>
                <li><a href="#" className="hover:text-primary">Автокредит</a></li>
                <li><a href="#" className="hover:text-primary">Trade-in</a></li>
                <li><a href="#" className="hover:text-primary">Сервис</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Контакты</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>+7 (495) 123-45-67</li>
                <li>info@koreanautohub.ru</li>
                <li>Москва, ул. Автомобилистов, 15</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              © 2024 Korean Auto Hub. Все права защищены.
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <CarDetailModal
        car={selectedCar}
        isOpen={isCarDetailOpen}
        onClose={() => setIsCarDetailOpen(false)}
      />

      <ShoppingCart onCheckout={() => setIsCheckoutOpen(true)} />

      <CheckoutForm
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
      />
    </div>
  );
}
