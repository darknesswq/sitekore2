import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { orderRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Cars API
  app.get("/api/cars", async (req, res) => {
    try {
      const { brand, search, brands, minPrice, maxPrice, year, bodyTypes } = req.query;
      
      let cars;
      
      if (search) {
        cars = await storage.searchCars(search as string);
      } else if (brand) {
        cars = await storage.getCarsByBrand(brand as string);
      } else if (brands || minPrice || maxPrice || year || bodyTypes) {
        const filters: any = {};
        
        if (brands) {
          filters.brands = Array.isArray(brands) ? brands : [brands];
        }
        if (minPrice) {
          filters.minPrice = parseFloat(minPrice as string);
        }
        if (maxPrice) {
          filters.maxPrice = parseFloat(maxPrice as string);
        }
        if (year) {
          filters.year = parseInt(year as string);
        }
        if (bodyTypes) {
          filters.bodyTypes = Array.isArray(bodyTypes) ? bodyTypes : [bodyTypes];
        }
        
        cars = await storage.filterCars(filters);
      } else {
        cars = await storage.getCars();
      }
      
      res.json(cars);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching cars: " + error.message });
    }
  });

  app.get("/api/cars/:id", async (req, res) => {
    try {
      const car = await storage.getCar(req.params.id);
      if (!car) {
        return res.status(404).json({ message: "Car not found" });
      }
      res.json(car);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching car: " + error.message });
    }
  });

  // Cart API
  app.get("/api/cart", async (req, res) => {
    try {
      const sessionId = req.ip || 'default-session';
      const cartItems = await storage.getCartItems(sessionId);
      res.json(cartItems);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching cart: " + error.message });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const sessionId = req.ip || 'default-session';
      const { carId } = req.body;
      
      if (!carId) {
        return res.status(400).json({ message: "Car ID is required" });
      }

      const car = await storage.getCar(carId);
      if (!car) {
        return res.status(404).json({ message: "Car not found" });
      }

      const cartItem = await storage.addToCart({ carId, sessionId });
      res.json(cartItem);
    } catch (error: any) {
      res.status(500).json({ message: "Error adding to cart: " + error.message });
    }
  });

  app.delete("/api/cart/:carId", async (req, res) => {
    try {
      const sessionId = req.ip || 'default-session';
      await storage.removeFromCart(sessionId, req.params.carId);
      res.json({ message: "Item removed from cart" });
    } catch (error: any) {
      res.status(500).json({ message: "Error removing from cart: " + error.message });
    }
  });

  app.delete("/api/cart", async (req, res) => {
    try {
      const sessionId = req.ip || 'default-session';
      await storage.clearCart(sessionId);
      res.json({ message: "Cart cleared" });
    } catch (error: any) {
      res.status(500).json({ message: "Error clearing cart: " + error.message });
    }
  });

  // Orders API
  app.post("/api/orders", async (req, res) => {
    try {
      const sessionId = req.ip || 'default-session';
      
      // Validate request body
      const orderData = orderRequestSchema.parse(req.body);
      
      // Get cart items for order
      const cartItems = await storage.getCartItems(sessionId);
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }

      const carIds = cartItems.map(item => item.carId);

      const order = await storage.createOrder({
        ...orderData,
        carIds,
      });

      // Clear the cart after successful order submission
      await storage.clearCart(sessionId);

      res.json(order);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Error creating order: " + error.message });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching order: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
