import { type User, type InsertUser, type Car, type InsertCar, type CartItem, type InsertCartItem, type Order, type InsertOrder } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Cars
  getCars(): Promise<Car[]>;
  getCar(id: string): Promise<Car | undefined>;
  getCarsByBrand(brand: string): Promise<Car[]>;
  searchCars(query: string): Promise<Car[]>;
  filterCars(filters: {
    brands?: string[];
    minPrice?: number;
    maxPrice?: number;
    year?: number;
    bodyTypes?: string[];
  }): Promise<Car[]>;
  
  // Cart
  getCartItems(sessionId: string): Promise<(CartItem & { car: Car })[]>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  removeFromCart(sessionId: string, carId: string): Promise<void>;
  clearCart(sessionId: string): Promise<void>;
  
  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private cars: Map<string, Car>;
  private cartItems: Map<string, CartItem>;
  private orders: Map<string, Order>;

  constructor() {
    this.users = new Map();
    this.cars = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    
    // Initialize with Korean car data
    this.initializeCars();
  }

  private initializeCars() {
    const carsData: Omit<Car, 'id'>[] = [
      {
        name: "Hyundai Elantra",
        brand: "Hyundai",
        model: "Elantra",
        year: 2024,
        price: "1850000",
        engine: "2.0L",
        power: "147 л.с.",
        drivetrain: "Передний",
        transmission: "CVT",
        fuelConsumption: "6.5л/100км",
        bodyType: "sedan",
        image: "https://images.unsplash.com/photo-1619767886558-efdc259cde1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1619767886558-efdc259cde1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
          "https://images.unsplash.com/photo-1619767886558-efdc259cde1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Современный седан с передовыми технологиями безопасности и комфорта.",
        features: ["Кондиционер", "Круиз-контроль", "Камера заднего вида", "Подогрев сидений", "Bluetooth"],
        rating: "4.8",
        status: "new",
        isNew: true,
      },
      {
        name: "Kia Sportage",
        brand: "Kia",
        model: "Sportage",
        year: 2024,
        price: "2450000",
        engine: "2.4L Turbo",
        power: "185 л.с.",
        drivetrain: "Полный",
        transmission: "8AT",
        fuelConsumption: "8.2л/100км",
        bodyType: "suv",
        image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Надежный и современный SUV для активного образа жизни.",
        features: ["AWD", "Панорамная крыша", "Подогрев руля", "Система помощи парковки", "Премиум аудио"],
        rating: "4.9",
        status: "available",
        isNew: true,
      },
      {
        name: "Genesis G90",
        brand: "Genesis",
        model: "G90",
        year: 2024,
        price: "4200000",
        engine: "3.5L V6",
        power: "375 л.с.",
        drivetrain: "Полный",
        transmission: "8AT",
        fuelConsumption: "10.5л/100км",
        bodyType: "sedan",
        image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Премиальный седан с роскошной отделкой и передовыми технологиями.",
        features: ["Массажные сидения", "Bang & Olufsen аудио", "Адаптивная подвеска", "HUD дисплей", "Беспроводная зарядка"],
        rating: "4.9",
        status: "premium",
        isNew: true,
      },
      {
        name: "Hyundai Tucson",
        brand: "Hyundai",
        model: "Tucson",
        year: 2024,
        price: "2150000",
        engine: "2.5L",
        power: "192 л.с.",
        drivetrain: "Передний",
        transmission: "8AT",
        fuelConsumption: "7.8л/100км",
        bodyType: "suv",
        image: "https://images.unsplash.com/photo-1609521263047-f8f205293f24?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1609521263047-f8f205293f24?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Популярный кроссовер с современным дизайном и богатым оснащением.",
        features: ["SmartSense", "Цифровая приборная панель", "Беспроводный Android Auto", "Климат-контроль", "LED фары"],
        rating: "4.7",
        status: "hit",
        isNew: true,
      },
      {
        name: "Kia EV6",
        brand: "Kia",
        model: "EV6",
        year: 2024,
        price: "3200000",
        engine: "Электро",
        power: "320 л.с.",
        drivetrain: "Полный",
        transmission: "Электро",
        fuelConsumption: "16.5 кВт*ч/100км",
        bodyType: "suv",
        image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1617788138017-80ad40651399?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Инновационный электрический кроссовер будущего.",
        features: ["Быстрая зарядка 350 кВт", "Дальность 528 км", "V2L функция", "Релаксационные сидения", "Augmented Reality HUD"],
        rating: "4.8",
        status: "electric",
        isNew: true,
      },
      {
        name: "Genesis G70",
        brand: "Genesis",
        model: "G70",
        year: 2024,
        price: "3750000",
        engine: "3.3L Twin Turbo",
        power: "370 л.с.",
        drivetrain: "Задний",
        transmission: "8AT",
        fuelConsumption: "9.8л/100км",
        bodyType: "sedan",
        image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
        images: [
          "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
        ],
        description: "Спортивный премиальный седан с превосходной динамикой.",
        features: ["Спортивный режим", "Brembo тормоза", "Дифференциал повышенного трения", "Карбоновые вставки", "19' диски"],
        rating: "4.9",
        status: "sport",
        isNew: true,
      },
    ];

    carsData.forEach(carData => {
      const id = randomUUID();
      this.cars.set(id, { ...carData, id });
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCars(): Promise<Car[]> {
    return Array.from(this.cars.values());
  }

  async getCar(id: string): Promise<Car | undefined> {
    return this.cars.get(id);
  }

  async getCarsByBrand(brand: string): Promise<Car[]> {
    return Array.from(this.cars.values()).filter(car => car.brand === brand);
  }

  async searchCars(query: string): Promise<Car[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.cars.values()).filter(car => 
      car.name.toLowerCase().includes(lowerQuery) ||
      car.brand.toLowerCase().includes(lowerQuery) ||
      car.model.toLowerCase().includes(lowerQuery)
    );
  }

  async filterCars(filters: {
    brands?: string[];
    minPrice?: number;
    maxPrice?: number;
    year?: number;
    bodyTypes?: string[];
  }): Promise<Car[]> {
    let result = Array.from(this.cars.values());

    if (filters.brands && filters.brands.length > 0) {
      result = result.filter(car => filters.brands!.includes(car.brand));
    }

    if (filters.minPrice !== undefined) {
      result = result.filter(car => parseFloat(car.price) >= filters.minPrice!);
    }

    if (filters.maxPrice !== undefined) {
      result = result.filter(car => parseFloat(car.price) <= filters.maxPrice!);
    }

    if (filters.year) {
      result = result.filter(car => car.year === filters.year);
    }

    if (filters.bodyTypes && filters.bodyTypes.length > 0) {
      result = result.filter(car => filters.bodyTypes!.includes(car.bodyType));
    }

    return result;
  }

  async getCartItems(sessionId: string): Promise<(CartItem & { car: Car })[]> {
    const items = Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
    return items.map(item => ({
      ...item,
      car: this.cars.get(item.carId)!
    })).filter(item => item.car);
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if car is already in cart
    const existing = Array.from(this.cartItems.values()).find(
      item => item.sessionId === cartItem.sessionId && item.carId === cartItem.carId
    );
    
    if (existing) {
      return existing;
    }

    const id = randomUUID();
    const newItem: CartItem = { ...cartItem, id };
    this.cartItems.set(id, newItem);
    return newItem;
  }

  async removeFromCart(sessionId: string, carId: string): Promise<void> {
    const itemToRemove = Array.from(this.cartItems.entries()).find(
      ([_, item]) => item.sessionId === sessionId && item.carId === carId
    );
    
    if (itemToRemove) {
      this.cartItems.delete(itemToRemove[0]);
    }
  }

  async clearCart(sessionId: string): Promise<void> {
    const itemsToRemove = Array.from(this.cartItems.entries()).filter(
      ([_, item]) => item.sessionId === sessionId
    );
    
    itemsToRemove.forEach(([id]) => {
      this.cartItems.delete(id);
    });
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const newOrder: Order = { 
      ...order, 
      id, 
      status: "new",
      comments: order.comments || null
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }
}

export const storage = new MemStorage();
