# ⚡ Быстрый деплой на Vercel - Шпаргалка

## 🚀 За 5 минут

### 1. Подготовка (1 мин)
```bash
npm install
npm run build  # Проверьте, что сборка работает
```

### 2. База данных (2 мин)
1. Создайте аккаунт на [neon.tech](https://neon.tech)
2. Создайте новый проект
3. Скопируйте `DATABASE_URL`

### 3. Vercel деплой (2 мин)
1. Перейдите на [vercel.com](https://vercel.com)
2. Нажмите "New Project" → выберите GitHub репозиторий
3. Настройки:
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist/public`
   - **Install Command**: `npm install`

### 4. Переменные окружения (30 сек)
В Vercel Dashboard → Settings → Environment Variables:
```
DATABASE_URL = postgresql://username:password@host/dbname?sslmode=require
NODE_ENV = production
```

### 5. Миграции базы данных
```bash
DATABASE_URL="ваш-продакшн-url" npm run db:push
```

## ✅ Готово!
Ваш сайт доступен по ссылке от Vercel.

---

**Нужна помощь?** Смотрите полную инструкцию в `DEPLOY_GUIDE.md` 