# 🚀 Полная инструкция по деплою KoreanWheels на Vercel

## 📋 Оглавление
1. [Предварительные требования](#предварительные-требования)
2. [Настройка базы данных](#настройка-базы-данных)
3. [Подготовка проекта](#подготовка-проекта)
4. [Деплой на Vercel](#деплой-на-vercel)
5. [Настройка переменных окружения](#настройка-переменных-окружения)
6. [Финальные шаги](#финальные-шаги)
7. [Устранение неполадок](#устранение-неполадок)

## 🔧 Предварительные требования

### 1. Необходимые аккаунты:
- ✅ Аккаунт на [Vercel](https://vercel.com)
- ✅ Аккаунт на [Neon](https://neon.tech) или другом PostgreSQL провайдере
- ✅ GitHub аккаунт (для интеграции с Vercel)
- ✅ Stripe аккаунт (для платежей) - опционально

### 2. Локальные инструменты:
```bash
# Node.js версии 18 или выше
node --version

# npm или yarn
npm --version

# Git
git --version
```

## 🗄️ Настройка базы данных

### Вариант 1: Neon Database (рекомендуется)

1. **Создайте аккаунт на Neon.tech**
   - Перейдите на [neon.tech](https://neon.tech)
   - Зарегистрируйтесь или войдите в систему

2. **Создайте новый проект**
   - Нажмите "Create Project"
   - Выберите регион (желательно близкий к вашим пользователям)
   - Запишите данные для подключения

3. **Получите строку подключения**
   ```
   postgresql://username:password@host/dbname?sslmode=require
   ```

### Вариант 2: Другие PostgreSQL провайдеры
- **Supabase**: [supabase.com](https://supabase.com)
- **Railway**: [railway.app](https://railway.app)
- **PlanetScale**: [planetscale.com](https://planetscale.com)

## 🛠️ Подготовка проекта

### 1. Клонирование репозитория
```bash
# Если еще не клонировали
git clone <your-repo-url>
cd KoreanWheels
```

### 2. Установка зависимостей
```bash
npm install
```

### 3. Создание .env файла для локальной разработки
```bash
# Создайте файл .env в корне проекта
touch .env
```

Содержимое `.env`:
```env
# База данных
DATABASE_URL=postgresql://username:password@host/dbname?sslmode=require

# Stripe (опционально)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...

# Другие переменные
NODE_ENV=production
PORT=5000
```

### 4. Инициализация базы данных
```bash
# Применить миграции
npm run db:push
```

### 5. Тестирование локально
```bash
# Сборка проекта
npm run build

# Запуск в продакшн режиме
npm start
```

## 🚀 Деплой на Vercel

### Метод 1: Через GitHub (рекомендуется)

1. **Загрузите код в GitHub**
   ```bash
   # Если репозиторий еще не создан
   git add .
   git commit -m "Prepare for Vercel deployment"
   git push origin main
   ```

2. **Подключите проект к Vercel**
   - Перейдите на [vercel.com](https://vercel.com)
   - Нажмите "New Project"
   - Выберите ваш GitHub репозиторий
   - Нажмите "Import"

3. **Настройте проект**
   - **Framework Preset**: Other
   - **Root Directory**: `./` (корень проекта)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist/public`
   - **Install Command**: `npm install`

### Метод 2: Через Vercel CLI

1. **Установите Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **Войдите в аккаунт**
   ```bash
   vercel login
   ```

3. **Деплой проекта**
   ```bash
   vercel --prod
   ```

## ⚙️ Настройка переменных окружения

### В панели управления Vercel:

1. **Перейдите в Settings → Environment Variables**

2. **Добавьте следующие переменные:**

   | Название | Значение | Среда |
   |----------|----------|-------|
   | `DATABASE_URL` | `postgresql://username:password@host/dbname?sslmode=require` | Production, Preview |
   | `NODE_ENV` | `production` | Production |
   | `STRIPE_SECRET_KEY` | `sk_live_...` или `sk_test_...` | Production, Preview |
   | `STRIPE_PUBLISHABLE_KEY` | `pk_live_...` или `pk_test_...` | Production, Preview |

3. **Сохраните изменения**

### Через Vercel CLI:
```bash
# Добавление переменных через CLI
vercel env add DATABASE_URL
vercel env add NODE_ENV
vercel env add STRIPE_SECRET_KEY
vercel env add STRIPE_PUBLISHABLE_KEY
```

## 🎯 Финальные шаги

### 1. Настройка домена (опционально)
```bash
# Добавление кастомного домена
vercel domains add yourdomain.com
```

### 2. Настройка миграций базы данных
После первого деплоя выполните:
```bash
# Подключитесь к продакшн базе и выполните миграции
DATABASE_URL="your-production-db-url" npm run db:push
```

### 3. Проверка деплоя
- ✅ Откройте ваш сайт по URL от Vercel
- ✅ Проверьте работу API: `https://your-app.vercel.app/api/cars`
- ✅ Убедитесь, что фронтенд загружается корректно
- ✅ Протестируйте основные функции

### 4. Настройка мониторинга
В Vercel Dashboard:
- **Analytics**: включите для отслеживания трафика
- **Speed Insights**: для мониторинга производительности
- **Functions**: проверьте логи serverless функций

## 🔧 Устранение неполадок

### Проблема: "Module not found"
```bash
# Убедитесь, что все зависимости установлены
npm install

# Проверьте package.json на корректность
npm run check
```

### Проблема: "Database connection failed"
1. Проверьте корректность `DATABASE_URL`
2. Убедитесь, что база данных доступна извне
3. Проверьте настройки SSL

### Проблема: "Build failed"
```bash
# Локальная проверка сборки
npm run build

# Проверка TypeScript
npm run check
```

### Проблема: "Function timeout"
- Увеличьте `maxDuration` в `vercel.json`
- Оптимизируйте медленные запросы к базе данных

### Проблема: "Static files not found"
Проверьте конфигурацию в `vercel.json`:
```json
{
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "/server/index.ts"
    },
    {
      "src": "/(.*)",
      "dest": "/dist/public/$1"
    }
  ]
}
```

## 📝 Дополнительные рекомендации

### 1. Безопасность
- ✅ Используйте переменные окружения для всех секретов
- ✅ Настройте CORS для продакшн домена
- ✅ Включите HTTPS (автоматически в Vercel)

### 2. Производительность
- ✅ Включите кэширование для статических ресурсов
- ✅ Оптимизируйте изображения
- ✅ Используйте CDN для ассетов

### 3. Мониторинг
- ✅ Настройте логирование ошибок
- ✅ Используйте Vercel Analytics
- ✅ Мониторьте производительность базы данных

## 🎉 Готово!

Ваш проект KoreanWheels теперь развернут на Vercel! 

**Полезные ссылки:**
- 📖 [Документация Vercel](https://vercel.com/docs)
- 🐛 [Отладка на Vercel](https://vercel.com/docs/concepts/functions/serverless-functions/troubleshooting)
- 💬 [Сообщество Vercel](https://github.com/vercel/vercel/discussions)

---

💡 **Совет**: Сохраните этот файл в вашем репозитории для будущих деплоев и обновлений! 